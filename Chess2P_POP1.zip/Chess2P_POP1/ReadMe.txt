README - Two player chess

14IT129
14IT139
14IT147
14IT204
14IT249

To run the game, after compilation, run Board.java, which has the main GUI function
of the project
Board.java sets up the GUI and takes in IP/OP clicks to move the pieces (White always 
moves first in Chess)
It passes both the IP/OP positions and the current game state to the main backend
function, Back.java.
Back.java sees if the move is valid and either gives out an error message if an
illegal move is made. Back.java makes use of the pieces package which contains classes
specific to each kind of piece on the chessboard

Conditions for an invalid move:
1) Move made out of turn i.e. one colour makes two moves in a row
2) Move is not compatible with the kind of piece selected i.e. rooks can't move
 diagonally
3) Move made is being blocked by another piece i.e. path is not empty
4) Move jeopardises own king i.e. if making a move puts your own king in check it is
 invalid
5) Move attempts to capture piece of same colout i.e. output click is in the position of
 a piece of same colour
6) Your own king is in check and the move you make does not remove the check on your own
 king

In all these cases the GUI pops up a dialogue box that has the message : Invalid

Checks and Checkmate:
If a move made by one colour, puts the opposing king in check, a dialogue box posts the
appropriate message
Also in the case of checkmate, there is an additional dialgue box that mentions : ENDGAME
Checkmate

Additional Resources:
There are 12 .png files each of which store the icons of all the pieces
These are imported from the resources folder when the GUI is being set up/repainted

ENJOY :)