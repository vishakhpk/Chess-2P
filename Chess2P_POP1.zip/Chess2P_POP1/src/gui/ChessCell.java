package gui;

import java.awt.Point;

import javax.swing.JButton;

@SuppressWarnings("serial")
public class ChessCell extends JButton{
	public Point coordinates;
}
